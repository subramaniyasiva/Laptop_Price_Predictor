window.onload = function() {
    const form = document.getElementById("specs-form");
    const inputs = form.querySelectorAll("input");
    const button = document.getElementById("sbutton");

    function checkInputs() {
        let allFilled = true;
        inputs.forEach(input => {
            if (input.value.trim() === "") {
                allFilled = false;
            }
        });
        button.style.display = allFilled ? "inline-block" : "none";
    }

    // Run on each input change
    inputs.forEach(input => {
        input.addEventListener("input", checkInputs);
    });

    // Hide button initially
    button.style.display = "none";
};


function getCookie(name) {
    let cookieValue = null;
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
        const trimmed = cookie.trim();
        if (trimmed.startsWith(name + '=')) {
            cookieValue = decodeURIComponent(trimmed.substring(name.length + 1));
            break;
        }
    }
    return cookieValue;
}

function refresh(){
    location.reload()
}