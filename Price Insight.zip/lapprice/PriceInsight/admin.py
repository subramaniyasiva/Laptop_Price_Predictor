from django.contrib import admin
from .models import specs


@admin.register(specs)
class specsadmin(admin.ModelAdmin):
    search_fields=['Brand','Model_name']
