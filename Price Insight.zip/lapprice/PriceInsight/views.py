from django.shortcuts import render, redirect
from .models import specs
import os
import pickle
from django.conf import settings
import pandas as pd  # Needed to pass input as DataFrame

# Load the ML model once
MODEL_PATH = os.path.join(settings.BASE_DIR, 'model', 'xgb_laptop_price_model.pkl')

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

# Home page
def home(request):
    return render(request, 'home.html')

# Save form data and predict price
def save_data(request):
    if request.method == 'POST':
        brand = request.POST.get('brand', '')
        model_name = request.POST.get('model_name', '')
        processor = request.POST.get('processor', '')
        cpu = request.POST.get('cpu', '')
        ram = request.POST.get('ram', '')
        ram_type = request.POST.get('ram_type', '')
        rom = request.POST.get('rom', '')
        rom_type = request.POST.get('rom_type', '')
        gpu = request.POST.get('gpu', '')
        display_size = request.POST.get('display_size', '')
        os_name = request.POST.get('os', '')

        # Save form data to DB
        obj = specs.objects.create(
            Brand=brand,
            Model_name=model_name,
            Processor=processor,
            CPU=cpu,
            RAM=ram,
            Ram_type=ram_type,
            ROM=rom,
            ROM_type=rom_type,
            GPU=gpu,
            display_size=display_size,
            OS=os_name
        )
        obj.save()

        # Prepare input data for prediction
        input_data = pd.DataFrame([{
    'Brand': brand,
    'Model_name': model_name,
    'processor': processor,       # lowercase
    'CPU': cpu,
    'Ram': ram,                   # 'Ram' not 'RAM'
    'Ram_type': ram_type,
    'ROM': rom,
    'ROM_type': rom_type,
    'GPU': gpu,
    'display_size': display_size,
    'OS': os_name
}])


        # Predict the price
        predicted_price = model.predict(input_data)[0]
        predicted_price = round(predicted_price, 2)
        print(model.named_steps['preprocessor'].feature_names_in_)
        print(predicted_price)


        return render(request, 'home.html', {'predicted_price': predicted_price})

    return redirect('home')
