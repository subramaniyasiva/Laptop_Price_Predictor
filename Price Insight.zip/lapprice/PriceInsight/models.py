from django.db import models
from django.utils import timezone
class specs(models.Model):  # Class names should be Capitalized by convention
    
    Brand = models.CharField(max_length=45)
    Model_name = models.CharField(max_length=45)
    Processor = models.CharField(max_length=45, null=False)
    CPU = models.CharField(max_length=45)
    RAM = models.CharField(max_length=6)
    Ram_type = models.CharField(max_length=9)
    ROM = models.CharField(max_length=9)
    ROM_type = models.CharField(max_length=23)
    GPU = models.CharField(max_length=35)
    display_size = models.FloatField()  # FloatField does not support max_length
    OS = models.CharField(max_length=25)
    # Predicted_Price=models.CharField(max_length=25,default=0)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)      # Updated every time you save

    def __str__(self):
        return f"{self.Brand} {self.Model_name}"
